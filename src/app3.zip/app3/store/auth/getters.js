import { getterTypes } from './types'

export default {
  [getterTypes.USER_INFO](state) {
    return state.userInfo
  }
}
