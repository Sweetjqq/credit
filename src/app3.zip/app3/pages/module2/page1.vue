<template lang="pug">
div
  | Module 2 - Page 1
</template>

<script>
export default {}
</script>
