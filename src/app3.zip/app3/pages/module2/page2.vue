<template lang="pug">
div
  | Module 2 - Page 2
</template>

<script>
export default {}
</script>
