<template>
<div>

  <el-form ref="form" :model="form" label-width="80px">

  <el-row>
    
  <el-col  :xs="10" :sm="10" :md="10" :lg="8" :xl="6">
<div class="block" style="margin-bottom:20px;">
  <label class="el-form-item__label" style="font-weight:700;">发行人</label>
 <el-select
 ref="issuer"
  collapse-tags
    v-model="value1"
    multiple
    filterable
    remote
    reserve-keyword
    placeholder="请输入关键词"
    :remote-method="remoteMethod1"
    :loading="loading">
    <el-option
      v-for="item in options4"
      :key="item.value"
      :label="item.label"
      :value="item.value">
    </el-option>
  </el-select>
</div>
  </el-col>

    <el-col  :xs="10" :sm="10" :md="10" :lg="8" :xl="6">
<div class="block" style="margin-bottom:20px;">
  <span class="el-form-item__label" style="font-weight:700;">债券名称</span>
 <el-select
 ref="bond"
    v-model="value2"
    multiple
    collapse-tags
    filterable
    remote
    reserve-keyword
    placeholder="请输入关键词"
    :remote-method="remoteMethod2"
    :loading="loading">
    <el-option
      v-for="item in options5"
      :key="item.value"
      :label="item.label"
      :value="item.value">
    </el-option>
  </el-select>
</div>
  </el-col>

  <el-col  :xs="12" :sm="12" :md="12" :lg="12" :xl="8">
 <el-form-item label="创建时间"  style="font-weight:700;float: left;text-align:  center;margin-left:-10px;">
    <el-col :span="11">
      <el-date-picker type="date" ref="data1" placeholder="选择日期" value-format="yyyy-MM-dd" v-model="form.date1" style="width: 100%;"></el-date-picker>
    </el-col>
    <el-col class="line" :span="2">-</el-col>
    <el-col :span="11">
      <el-time-picker type="fixed-time" ref="data2" placeholder="选择时间" value-format="yyyy-MM-dd" v-model="form.date2" style="width: 100%;"></el-time-picker>
    </el-col>
  </el-form-item>
  </el-col>
  <el-col :xs="8" :sm="8" :md="6" :lg="4" :xl="4">
  <el-button type="primary" plain class="btn" @click="search">查询</el-button>
  </el-col>

</el-row>
  </el-form>



  <div>
 
</div>

  <el-table

    :data="tableData"
    border
    style="width: 100% ;margin-top:20px;color:#50b4e0">
    <el-table-column
      fixed
      prop="date"
      label="报告名称"
     >
    </el-table-column>
    <el-table-column
      prop="name"
      label="发行人"
    >
    </el-table-column>
    <el-table-column
      prop="province"
      label="债券名称"
      >
    </el-table-column>
    <el-table-column
      prop="city"
      label="省份"
      >
    </el-table-column>
    <el-table-column
      prop="address"
      label="行业"
      >
    </el-table-column>
    <el-table-column
      prop="zip"
      label="创建时间"
     >
    </el-table-column>
    <el-table-column
      fixed="right"
      label="操作"
      >
      <template slot-scope="scope">
        <div style="display: inline-block;cursor:  pointer;"  @click="handleClickquery(scope.row)"><el-tag type="success" >查看</el-tag></div>
        <div style="display: inline-block;cursor:  pointer;" @click="handleClickupdate(scope.row)"> <el-tag type="info"   >修改</el-tag></div>
      </template>
    </el-table-column>
  </el-table>
  <el-pagination 
      @current-change="handleCurrentChange"  
  class="page"
  background
  layout="prev, pager, next"
  :total=t>
</el-pagination>
    </div>
</template>

<script>
export default {
  created(){
   //this.menu = menu;
  },
  mounted() {
    this.list1 = this.states1.map(item => {
      return { value: item, label: item };
    });
    this.list2 = this.states2.map(item => {
      return { value: item, label: item };
    });
    this.searchIusser();
    this.searchBond();
  },
  methods: {
    searchIusser() {
      console.log(this.$refs.bond.value);
      console.log("1");
    },
    searchBond() {
      console.log(this.$refs.issuer.value);
      console.log("2");
    },
    search() {
      console.log(this.$refs.issuer.value);
      console.log(this.$refs.bond.value);
      console.log(this.$refs.data1.value, this.$refs.data2.value);
    },

    handleCurrentChange(val) {
      console.log(`当前页:` + val);
    },
    remoteMethod1(query) {
      if (query !== "") {
        this.loading = true;
        setTimeout(() => {
          this.loading = false;
          this.options4 = this.list1.filter(item => {
            return item.label.toLowerCase().indexOf(query.toLowerCase()) > -1;
          });
        }, 200);
      } else {
        this.options4 = [];
      }
    },
    remoteMethod2(query) {
      if (query !== "") {
        this.loading = true;
        setTimeout(() => {
          this.loading = false;
          this.options5 = this.list2.filter(item => {
            return item.label.toLowerCase().indexOf(query.toLowerCase()) > -1;
          });
        }, 200);
      } else {
        this.options5 = [];
      }
    },
    handleClickupdate(row) {
      console.log(row);
    },
    handleClickquery(row) {
      console.log(row);
    }
  },

  data() {
    return {
      t: 100, // 总条数
      form: {
        name: ""
      },
      tableData: [
        {
          date: "2016-05-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-04",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1517 弄"
        },
        {
          date: "2016-05-01",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1519 弄"
        },
        {
          date: "2016-05-03",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1516 弄"
        }
      ],
      list1: [],
      list2: [],
      value1: "",
      value2: "",
      loading: false,
      states1: [
        "Alabama",
        "Alaska",
        "Arizona",
        "Arkansas",
        "California",
        "Colorado",
        "Connecticut",
        "Delaware",
        "Florida",
        "Georgia",
        "Hawaii",
        "Idaho",
        "Illinois",
        "Indiana",
        "Iowa",
        "Kansas",
        "Kentucky",
        "Louisiana",
        "Maine",
        "Maryland",
        "Massachusetts",
        "Michigan",
        "Minnesota",
        "Mississippi",
        "Missouri",
        "Montana",
        "Nebraska",
        "Nevada",
        "New Hampshire",
        "New Jersey",
        "New Mexico",
        "New York",
        "North Carolina",
        "North Dakota",
        "Ohio",
        "Oklahoma",
        "Oregon",
        "Pennsylvania",
        "Rhode Island",
        "South Carolina",
        "South Dakota",
        "Tennessee",
        "Texas",
        "Utah",
        "Vermont",
        "Virginia",
        "Washington",
        "West Virginia",
        "Wisconsin",
        "Wyoming"
      ],
      states2: [
        "Alabama",
        "Alaska",
        "Arizona",
        "Arkansas",
        "California",
        "Colorado",
        "Connecticut",
        "Delaware",
        "Florida",
        "Georgia",
        "Hawaii",
        "Idaho",
        "Illinois",
        "Indiana",
        "Iowa",
        "Kansas",
        "Kentucky",
        "Louisiana",
        "Maine",
        "Maryland",
        "Massachusetts",
        "Michigan",
        "Minnesota",
        "Mississippi",
        "Missouri",
        "Montana",
        "Nebraska",
        "Nevada",
        "New Hampshire",
        "New Jersey",
        "New Mexico",
        "New York",
        "North Carolina",
        "North Dakota",
        "Ohio",
        "Oklahoma",
        "Oregon",
        "Pennsylvania",
        "Rhode Island",
        "South Carolina",
        "South Dakota",
        "Tennessee",
        "Texas",
        "Utah",
        "Vermont",
        "Virginia",
        "Washington",
        "West Virginia",
        "Wisconsin",
        "Wyoming"
      ],
      options4: [],
      options5: [],
      value2: [],
      value11: []
    };
  }
};
</script>

<style scoped>
.page {
  text-align: right;
  margin-top: 15px;
}
.btn {
  margin-left: 20px;
}
</style>

