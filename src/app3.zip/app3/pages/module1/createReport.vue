<template>
<div>
  <el-row>
  <el-col :span="12" style="
    padding-top: 70px;  padding-left:70px;
">
<div style="
    padding-left: 26px;
">
  <label class="el-form-item__label"  style="font-weight:700;">发行人</label>
 <el-select
    ref="issuer"
    v-model="value9"
    multiple
    collapse-tags
    filterable
    remote
    reserve-keyword
    placeholder="请输入关键词"
    :remote-method="remoteMethod"
    :loading="loading">
    <el-option
      v-for="item in options4"
      :key="item.value"
      :label="item.label"
      :value="item.value">
    </el-option>
  </el-select>
  </div>
  <el-form ref="form" :model="form" label-width="80px" style="margin-top:28px;">
   <el-form-item label="季度" style="font-weight:700;text-align:  center;">
    <el-col :span="11">
      <el-date-picker type="date" ref="data1" value-format="yyyy-MM-dd" placeholder="选择日期" v-model="form.date1" style="width: 100%;"></el-date-picker>
    </el-col>
    <el-col class="line" :span="2">-</el-col>
    <el-col :span="11">
      <el-time-picker type="fixed-time" ref="data2" value-format="yyyy-MM-dd" placeholder="选择时间" v-model="form.date2" style="width: 100%;"></el-time-picker>
    </el-col>
     </el-form-item>
    <el-button type="primary" plain style="
    margin-left: 80px;margin:'10px'
" @click="createReportClick">创建报告</el-button>
  </el-form>
  </el-col>
</el-row>
    </div>
</template>
<script>
export default {
  methods: {},

  data() {
    return {
      options4: [],
      value9: [],
      list: [],
      loading:false,
      states: [
        "Alabama",
        "Alaska",
        "Arizona",
        "Arkansas",
        "California",
        "Colorado",
        "Connecticut",
        "Delaware",
        "Florida",
        "Georgia",
        "Hawaii",
        "Idaho",
        "Illinois",
        "Indiana",
        "Iowa",
        "Kansas",
        "Kentucky",
        "Louisiana",
        "Maine",
        "Maryland",
        "Massachusetts",
        "Michigan",
        "Minnesota",
        "Mississippi",
        "Missouri",
        "Montana",
        "Nebraska",
        "Nevada",
        "New Hampshire",
        "New Jersey",
        "New Mexico",
        "New York",
        "North Carolina",
        "North Dakota",
        "Ohio",
        "Oklahoma",
        "Oregon",
        "Pennsylvania",
        "Rhode Island",
        "South Carolina",
        "South Dakota",
        "Tennessee",
        "Texas",
        "Utah",
        "Vermont",
        "Virginia",
        "Washington",
        "West Virginia",
        "Wisconsin",
        "Wyoming"
      ],
      form: {
        name: "",
        data1:'',
        data2:''
      }
    };
  },
  mounted() {
    this.list = this.states.map(item => {
      return { value: item, label: item };
    });
  },
  methods: {
    search() {
      //请求到数据
      //this.list =
    },
    remoteMethod(query) {
      if (query !== "") {
        this.loading = true;
        setTimeout(() => {
          this.loading = false;
          this.options4 = this.list.filter(item => {
            return item.label.toLowerCase().indexOf(query.toLowerCase()) > -1;
          });
        }, 200);
      } else {
        this.options4 = [];
      }
    },
    //创建报告
    createReportClick(){
      console.log(this.$refs.issuer.value)
      console.log(this.$refs.data1.value,this.$refs.data2.value)
      
    }
  }
};
</script>
